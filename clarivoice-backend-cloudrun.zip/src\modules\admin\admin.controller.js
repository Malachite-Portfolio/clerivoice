const { asyncHandler } = require('../../utils/asyncHandler');
const { successResponse } = require('../../utils/apiResponse');
const adminService = require('./admin.service');

const listUsers = asyncHandler(async (req, res) => {
  const data = await adminService.listUsers(req.query);
  return successResponse(res, data);
});

const listListeners = asyncHandler(async (req, res) => {
  const data = await adminService.listListeners(req.query);
  return successResponse(res, data);
});

const updateListenerRates = asyncHandler(async (req, res) => {
  const data = await adminService.updateListenerRates({
    listenerId: req.params.id,
    ...req.body,
  });
  return successResponse(res, data, 'Listener rates updated');
});

const updateListenerStatus = asyncHandler(async (req, res) => {
  const data = await adminService.updateListenerStatus({
    listenerId: req.params.id,
    payload: req.body,
  });
  return successResponse(res, data, 'Listener status updated');
});

const updateListenerVisibility = asyncHandler(async (req, res) => {
  const data = await adminService.updateListenerVisibility({
    listenerId: req.params.id,
    visible: req.body.visible,
  });
  return successResponse(res, data, 'Listener visibility updated');
});

const removeListenerSoft = asyncHandler(async (req, res) => {
  const data = await adminService.removeListenerSoft({
    listenerId: req.params.id,
    adminId: req.user.id,
    reason: req.body.reason,
  });
  return successResponse(res, data, 'Listener removed successfully');
});

const listWalletLedger = asyncHandler(async (req, res) => {
  const data = await adminService.listWalletLedger({
    page: Number(req.query.page || 1),
    limit: Number(req.query.limit || 20),
    userId: req.query.userId,
  });
  return successResponse(res, data);
});

const listChatSessions = asyncHandler(async (req, res) => {
  const data = await adminService.listChatSessions({
    page: Number(req.query.page || 1),
    limit: Number(req.query.limit || 20),
  });
  return successResponse(res, data);
});

const listCallSessions = asyncHandler(async (req, res) => {
  const data = await adminService.listCallSessions({
    page: Number(req.query.page || 1),
    limit: Number(req.query.limit || 20),
  });
  return successResponse(res, data);
});

const manualWalletAdjustment = asyncHandler(async (req, res) => {
  const data = await adminService.manualWalletAdjustment({
    ...req.body,
    adminId: req.user.id,
  });
  return successResponse(res, data, 'Wallet adjusted successfully');
});

const listRechargePlans = asyncHandler(async (_req, res) => {
  const data = await adminService.listRechargePlans();
  return successResponse(res, { plans: data });
});

const createRechargePlan = asyncHandler(async (req, res) => {
  const data = await adminService.createRechargePlan(req.body);
  return successResponse(res, data, 'Recharge plan created');
});

const updateRechargePlan = asyncHandler(async (req, res) => {
  const data = await adminService.updateRechargePlan({
    id: Number(req.params.id),
    payload: req.body,
  });
  return successResponse(res, data, 'Recharge plan updated');
});

const getReferralRule = asyncHandler(async (_req, res) => {
  const data = await adminService.getReferralRule();
  return successResponse(res, data);
});

const updateReferralRule = asyncHandler(async (req, res) => {
  const data = await adminService.updateReferralRule(req.body);
  return successResponse(res, data, 'Referral rule updated');
});

module.exports = {
  listUsers,
  listListeners,
  updateListenerRates,
  updateListenerStatus,
  updateListenerVisibility,
  removeListenerSoft,
  listWalletLedger,
  listChatSessions,
  listCallSessions,
  manualWalletAdjustment,
  listRechargePlans,
  createRechargePlan,
  updateRechargePlan,
  getReferralRule,
  updateReferralRule,
};
